import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:music_app/Controllers/player_controller.dart';
import 'package:on_audio_query/on_audio_query.dart';
import 'package:permission_handler/permission_handler.dart';

class home extends StatefulWidget {
  const home({super.key});

  @override
  State<home> createState() => _homeState();
}

class _homeState extends State<home> {
  @override
  Widget build(BuildContext context) {
    var controller= Get.put(PlayerController());

    return Scaffold(
      appBar: AppBar(
        actions: [
          IconButton(onPressed: (){}, icon: Icon(Icons.search))
        ],
        leading: Icon(Icons.sort_rounded),
        title: Text(
          'Music',
              style: TextStyle(
                fontSize: 18,

        )
        ),
      ),

      body:FutureBuilder<List<SongModel>>(
        future: controller.audioQuery.querySongs(
          ignoreCase: true,
          orderType: OrderType.ASC_OR_SMALLER,
          sortType: null,
          uriType: UriType.EXTERNAL,
        ),
        builder: (BuildContext context, snapshot){
          if(snapshot.data==null){
            return Center(
              child: CircularProgressIndicator(),
            );
          }
          else if(snapshot.data!.isEmpty){
            return Center(
              child: Text(
                "no audio found"
              ),
            );
          }
          return Padding(
            padding: const EdgeInsets.all(18),
            child: ListView.builder(
                itemCount: 50,
                itemBuilder: (BuildContext context, int index){
                  return Container(
                    child: const ListTile(
                      title: Text(
                        'song name',
                        style: TextStyle(fontSize: 15),
                      ),

                      subtitle: Text(
                        'artist name',
                        style: TextStyle(fontSize: 12),
                      ),
                      leading: Icon(
                        Icons.music_note,
                        size: 32,
                      ),

                      trailing:Icon(
                        Icons.play_arrow,
                        size: 26,
                      ),



                    ),




                  );


                }


            ),
          );

        },

      )
    );
  }
}
